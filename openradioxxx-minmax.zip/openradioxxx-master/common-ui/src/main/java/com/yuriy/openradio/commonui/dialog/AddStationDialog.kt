package com.yuriy.openradio.commonui.dialog

import android.app.Dialog
import android.os.Bundle

class AddStationDialog : BaseDialogFragment() {
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return super.onCreateDialog(savedInstanceState)
    }
}
